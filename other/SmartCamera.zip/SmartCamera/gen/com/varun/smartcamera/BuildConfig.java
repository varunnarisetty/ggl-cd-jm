/** Automatically generated file. DO NOT MODIFY */
package com.varun.smartcamera;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}