package com.varun.smartcamera;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class MyView extends View {
	
	private boolean selctionMode;
	private Bitmap selectionImage;
	private Bitmap clipBitmap;
	private RectF mRectf;
	private Paint mPaint;
	
	private float left,top,right,bottom;
	public MyView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init();	
	}

	public MyView(Context context) {
		super(context);
		init();	
	}
	
	
	
	
	private void init() {
		
		mRectf = new RectF(0,0,0,0);
		mPaint = new Paint();
		mPaint.setStrokeWidth(5);
		mPaint.setStyle(Style.STROKE);
		
		
	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		if(selectionImage!= null){
			canvas.drawBitmap(selectionImage, 0, 0, null);
		}
		if(clipBitmap!=null){
		canvas.clipRect(mRectf);
		canvas.drawBitmap(clipBitmap, 0, 0, null);
		canvas.restore();
		}
		if(selctionMode){
			canvas.drawRect(mRectf, mPaint);
		}
	}
	
	
	@Override
	public boolean onTouchEvent(MotionEvent event) {
	
		if(selctionMode){
		switch (event.getAction()) {
		case MotionEvent.ACTION_DOWN:
			left = event.getX();
			top = event.getY();
			break;
		case MotionEvent.ACTION_MOVE:
			right = event.getX();
			bottom = event.getY();
			if((right-left)>0 && (bottom - top)>0){
				mRectf = new RectF(left, top, right, bottom);
			}
			break;
		case MotionEvent.ACTION_UP:
			break;
		default:
			break;
		}
		invalidate();
		return true;
		}else{
			return false;
		}
		
	}

	public boolean isSelctionMode() {
		return selctionMode;
	}

	public void setSelctionMode(boolean selctionMode) {
		this.selctionMode = selctionMode;
	}

	public Bitmap getSelectionImage() {
		return selectionImage;
	}

	public void setSelectionImage(Bitmap selectionImage) {
		this.selectionImage = selectionImage;
	}

	public RectF getmRectf() {
		return mRectf;
	}

	public void setmRectf(RectF mRectf) {
		this.mRectf = mRectf;
	}
	
	public Bitmap getClipBitmap() {
		return clipBitmap;
	}

	public void setClipBitmap(Bitmap clipBitmap) {
		this.clipBitmap = clipBitmap;
	}

	
	

}
