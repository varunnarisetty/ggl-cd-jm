package com.varun.smartcamera;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SmartCameraActivity extends Activity {
	private static final int MODE_INIT = 0;
	private static final int MODE_LOAD = 1;
	private static final int MODE_CLIP = 2;
	private static final int MODE_ADJUST = 3;

	
	private Button b1;
	private Button b2;
	private Button b3;
	private MyView canvas;
	private int selection = -1;
	private int mode = 0;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        b1 = (Button)findViewById(R.id.button1);
        b2 = (Button)findViewById(R.id.button2);
        b3 = (Button)findViewById(R.id.button3);
        
        canvas = (MyView)findViewById(R.id.myView1);
        
        
        b1.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
			
				switch (mode) {
				case MODE_INIT:
					canvas.setSelectionImage(BitmapFactory.decodeFile("/sdcard/smartCamera/1.jpg"));
					mode = MODE_LOAD;
					b1.setText("clip");
					canvas.invalidate();
					break;
				case MODE_LOAD:
					canvas.setSelctionMode(true);
					mode = MODE_CLIP;
					b1.setText("OK");
					canvas.invalidate();
					break;
				case MODE_CLIP:
					
					mode = MODE_ADJUST;
					b1.setText("Done");
					canvas.invalidate();
					break;
				case MODE_ADJUST:
					canvas.setSelctionMode(false);
					mode = MODE_INIT;
					b1.setText("Load");
					canvas.invalidate();
					break;
				}
				
			}
		});
        
        b2.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(mode == MODE_ADJUST){
				if(selection == 1 || selection == -1 || selection == 0 ){
					selection = 10;
				}else{
					selection--;
				}
				Bitmap selectBmp = getSelectionBitmap(selection);
				canvas.setClipBitmap(selectBmp);
				canvas.invalidate();
				}
			}
		});
        
        b3.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(mode == MODE_ADJUST){
				if(selection == -1 || selection == 10 ){
					selection = 1;
				}else{
					selection++;
				}
				Bitmap selectBmp = getSelectionBitmap(selection);
				canvas.setClipBitmap(selectBmp);
				canvas.invalidate();
				}
			}
		});
    }
    
    
    private Bitmap getSelectionBitmap(int selection){
    	return BitmapFactory.decodeFile("/sdcard/smartCamera/"+selection+".jpg");
    	/*switch (selection) {
    	
    	case -1:
    		return null;
    	case 1:
    		
		case 2:
			return BitmapFactory.decodeResource(getResources(), R.drawable.bmp2);
		case 3:
			return BitmapFactory.decodeResource(getResources(), R.drawable.bmp3);
		case 4:
			return BitmapFactory.decodeResource(getResources(), R.drawable.bmp4);
		default:
			return null;
		}*/
    }
}