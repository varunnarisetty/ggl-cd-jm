package com.varun.smartcamera;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import android.app.Activity;
import android.content.Intent;
import android.hardware.Camera;
import android.hardware.Camera.PictureCallback;
import android.hardware.Camera.ShutterCallback;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.FrameLayout;

public class MainActivity extends Activity {
	  private static final String TAG = "CameraDemo";
	  Preview preview; // <1>
	  Button buttonClick; // <2>
	  Handler handle;
	  int i =1;
	  /** Called when the activity is first created. */
	  @Override
	  public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.main1);
	    File file = new File("/sdcard/smartCamera/");
	    file.mkdirs();
	    
	    preview = new Preview(this); // <3>
	    ((FrameLayout) findViewById(R.id.preview)).addView(preview); // <4>

	    buttonClick = (Button) findViewById(R.id.buttonClick);
	    buttonClick.setOnClickListener(new OnClickListener() {
	      public void onClick(View v) { // <5>
	        preview.camera.takePicture(shutterCallback, rawCallback, jpegCallback);
	      }
	    });
	    
	    handle = new Handler(){
	    	@Override
	    	public void handleMessage(Message msg) {
	    		if(msg.what != -1){
	    			preview.camera.takePicture(shutterCallback, rawCallback, jpegCallback);
	        		super.handleMessage(msg);	
	    		}else{
	    			Intent intent = new Intent(getApplicationContext(), SmartCameraActivity.class);
	    			startActivity(intent);
	    			finish();
	    		}
	    	}
	    };
	    
	    Log.d(TAG, "onCreate'd");
	  }

	  

	  @Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		preview.camera.stopPreview();
//		preview.camera.release();
//		preview.camera = null;
		i = 1;
	}



	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		i = 1;
		File[] files = new File("/sdcard/smartCamera").listFiles();
		for(File file:files)
		{
			file.delete();
		}
	}



	// Called when shutter is opened
	  ShutterCallback shutterCallback = new ShutterCallback() { // <6>
	    public void onShutter() {
	      Log.d(TAG, "onShutter'd");
	    }
	  };

	  // Handles data for raw picture
	  PictureCallback rawCallback = new PictureCallback() { // <7>
	    public void onPictureTaken(byte[] data, Camera camera) {
	      Log.d(TAG, "onPictureTaken - raw");
	    }
	  };

	  // Handles data for jpeg picture
	  PictureCallback jpegCallback = new PictureCallback() { // <8>
	    public void onPictureTaken(byte[] data, Camera camera) {
	      FileOutputStream outStream = null;
	      try {
	        // Write to SD Card
	        outStream = new FileOutputStream(String.format("/sdcard/smartCamera/"+i+".jpg",
	            System.currentTimeMillis())); // <9>
	        outStream.write(data);
	        outStream.close();
	        if(i<10){
	        	handle.sendEmptyMessage(10);
	        	i++;
	        }else{
	        	handle.sendEmptyMessage(-1);	
	        }
	        
	        Log.d(TAG, "onPictureTaken - wrote bytes: " + data.length);
	      } catch (FileNotFoundException e) { // <10>
	        e.printStackTrace();
	      } catch (IOException e) {
	        e.printStackTrace();
	      } finally {
	      }
	      Log.d(TAG, "onPictureTaken - jpeg");
	    }
	  };
	  
	  

}





